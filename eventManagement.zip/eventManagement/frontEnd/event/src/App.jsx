
import Start from "./page/Start.jsx";
import Login from "./page/Login.jsx";
import SignUp from "./page/SignUp.jsx";
import AboutUs from "./page/AboutUs.jsx";

function App() {


  return (
    <>
     <AboutUs/>
    </>
  );
}

export default App
