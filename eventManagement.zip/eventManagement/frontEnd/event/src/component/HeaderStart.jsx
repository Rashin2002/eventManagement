import React from 'react';
import './HeaderStart.css';

const HeaderStart = () => {
  return (

    <header className="header">
      <div className="header-container">
        <div className="logo">
          <a href="/">EventLink Sri Lanka</a>
        </div>
        <nav className="nav-menu">
          <ul>
            <li><a href="/movies">Movies</a></li>
            <li><a href="/events">Events</a></li>
            <li><a href="/plays">Plays</a></li>
            <li><a href="/sports">Sports</a></li>

          </ul>
        </nav>
      </div>
    </header>
  );
};

export default HeaderStart;
