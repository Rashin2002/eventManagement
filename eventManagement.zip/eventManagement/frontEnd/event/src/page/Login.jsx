import React, { useState } from "react";
import './Login.css';

const Login = () => {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");

  const handleLogin = (e) => {
    e.preventDefault();
    console.log("Logging in with", { username, password });
  };

  return (
    <div className="login-container">
      <div className="login-box">
        <h2>Login</h2>
        <form onSubmit={handleLogin}>
          <div className="form-group">
            <label>Username</label>
            <input
              type="text"
              placeholder="Username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              required
            />
          </div>
          <div className="form-group">
            <label>Password</label>
            <input
              type="password"
              placeholder="Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>
          <div className="remember-section">
            <input type="checkbox" id="remember" />
            <label htmlFor="remember">Remember username</label>
          </div>
          <button type="submit">Log In</button>
        </form>
        {/* Add the Sign-Up link in the bottom left corner */}
        <a href="/sign-up" className="signup-link">Sign Up</a>
      </div>
    </div>
  );
};

export default Login;