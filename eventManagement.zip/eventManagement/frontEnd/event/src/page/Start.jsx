import HeaderStart from"../component/HeaderStart.jsx"
import FooterStart from "../component/FooterStart.jsx"

function Start(){
    return(
    <div>
        <HeaderStart/>
        <FooterStart/>
    </div>
    );
}
export default Start;