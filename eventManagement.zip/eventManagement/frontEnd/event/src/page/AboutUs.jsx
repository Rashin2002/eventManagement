import React from 'react';
import './AboutUs.css';

const AboutUs = () => {
  return (
    <div className="about-us">
      <h1>About Us</h1>
      <p>Welcome to EventLink – your premier destination for all things musical! We are passionate about bringing the best musical shows to life, connecting you with unforgettable performances from the artists you love. Whether you're a fan of classical concerts, rock gigs, or indie performances, EventLink is here to ensure you never miss a beat.</p>
      <p>At EventLink, we make it easy to discover, plan, and experience the finest musical events. Our platform is designed with both fans and organizers in mind, offering seamless ticketing, exclusive access, and up-to-date information on all the hottest shows.</p>
      <p>Join us on a journey through the vibrant world of music, where every note and every beat is just a click away. Whether you're looking to attend an intimate acoustic set or a grand stadium concert, EventLink is your trusted partner in creating unforgettable musical memories.</p>
      <p><strong>Let the music play!</strong></p>
    </div>
  );
};

export default AboutUs;
